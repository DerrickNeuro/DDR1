##DDR1 associated analysis after RNA-sequencing. 
##Load R packages.
library(clusterProfiler)
library(org.Mm.eg.db)
library(DOSE)
library(enrichplot)
library(GOplot)
library(DESeq2)
library(stringr)
#Extrating _count data profiles. 
{data <- read.csv("ct26_count_with_symbol.csv")
data <- read.table("ct26_count_with_symbol.csv",sep = ",",header = T,check.names = F)
data<- data[,-c(1,3)]
data<- data[!duplicated(data$Symbol),]
data<- subset(data, data$Symbol !="---", )
data<- as.data.frame(data)
rownames(data)<- data$Symbol
data<- data[,-1]
}

#Change working directory
dir.create("~/CT26")
setwd("~/CT26")

#Rename Groups
{new.cluster.ids<- c("NC_Col", "NC_Col+IFN", "sh1_Col", "sh1_Col+IFN",
                    "sh3_Col", "sh3_Col+IFN")
colnames(data) <- new.cluster.ids
}
##Specimen Correlation Examination
{
expcor <- cor(data, method = "spearman")
head(expcor)
pheatmap::pheatmap(expcor, clustering_method = "average",
                   treeheight_row = 0,treeheight_col = 0,
                   display_numbers = T)
}
##hclust for sample clustering
{
t_data <- t(data)
t_data <- t_data[,names(sort(apply(t_data,2,mad),decreasing = T))[1:500]]
out.dist <- dist(t_data,method = 'euclidean')
out.hclust <- hclust(out.dist,method = 'complete')
plot.new()
rect.hclust(out.hclust,k=3)
plot(out.hclust,xlab = "",main = "")
}
##Create Primary dds matrix and save as a .Rdata file for easy accessibility
##Group Sorting and Arrangement
{group_list <- factor(c(rep("NC_Col",1),rep("NC_Col_IFN",1), rep("sh_Col",1),  rep("sh_Col_IFN", 1), rep("sh_Col",1),  rep("sh_Col_IFN", 1)), 
                     levels = c("NC_Col","NC_Col_IFN", "sh_Col", "sh_Col_IFN") )
group_list
table(group_list)
}
{
colData <- data.frame(row.names = colnames(data),
                      group_list = group_list)
colData
dds <- DESeqDataSetFromMatrix(countData = data,
                              colData = colData,
                              design = ~group_list) 
#~在R里面用于构建公式对象，~左边为因变量，右边为自变量。
head(dds)
}
#Save dds as an .Rdata for easy use without construction.
tem_f <- 'CT26_RNAseq_DESeq2-dds.Rdata'

##Use DESeq2 for data normalization
dds <- DESeq(dds)

#Use function "result" to extract differential comparison.
{
#contrast: 2 groups for comparison
res = results(dds, contrast=c("group_list", "sh_Col_IFN", "NC_Col_IFN"))

#Order res file according to p val. 
res = res[order(res$pvalue),]

#Export comparison results. 
write.csv(res, file="CT26_sh vs NC_Col_IFN_results.csv")

#showing significant genes. 
table(res$padj<0.05)
}
#Creating subset groups log2FC abs larger than 1
diff_gene_Group2 <- subset(res, padj < 0.05 & abs(log2FoldChange) > 1)

#Save diff genes results into .csv file
write.csv(diff_gene_Group2, file = "CT26_sh to NC_Col_IFN.csv")



#Differential Analysis
{
  #Transform diff DESeq into dataframe. 
  df<- as.data.frame(res)
  
  #Drawing the volcano plots presenting the most different genes. 
  df$symbol <- rownames(df)
  logFC_t=0
  P.Value_t = 0.05
  df$change = ifelse(df$padj< P.Value_t & df$log2FoldChange < 0,"down",
                     ifelse(df$padj < P.Value_t & df$log2FoldChange > 0,"up","stable"))
  p<-ggplot(df, aes(log2FoldChange,  -log10(padj))) +
    geom_point(alpha=0.4, size=3.5, aes(color=change)) +
    ylab("-log10(Pvalue)")+
    scale_color_manual(values=c("blue", "grey","red"))+
    geom_hline(yintercept = -log10(P.Value_t),lty=4,col="black",lwd=0.8) +
    geom_vline(xintercept = 1, lty =4 , col="darkgreen", lwd=0.6)+
    geom_vline(xintercept = -1, lty =4 , col="darkgreen", lwd=0.6)+
    theme_bw()+ggtitle("CT26_Col+IFN sh vs NC")
  p
  ggsave(plot = p, filename = "CT26_Col+IFN sh vs NC_Volcano.png", width=6, height = 6)
  ggsave(plot = p, filename = "CT26_Col+IFN sh vs NC_Volcano.pdf", width=6, height = 6)
}
## Annotate variable features functions in GO/KEGG
{
  gene_up=rownames(df[df$log2FoldChange > 0,])
  
  gene_down=rownames(df[df$log2FoldChange < 0,])
  ## Transform gene symbol into entrezID
  gene_up=as.character(na.omit(AnnotationDbi::select(org.Mm.eg.db,
                                                     keys = gene_up,
                                                     columns = 'ENTREZID',
                                                     keytype = 'SYMBOL')[,2]))
  gene_down=as.character(na.omit(AnnotationDbi::select(org.Mm.eg.db,
                                                       keys = gene_down,
                                                       columns = 'ENTREZID',
                                                       keytype = 'SYMBOL')[,2]))
}

## Enrichment Analysis for elevated/declined genes
## KEGG Pathway
{gene_up <- unique(gene_up)
  kk.up <- enrichKEGG(gene = gene_up,
                      organism = "mmu",
                      pvalueCutoff = 0.05,
                      qvalueCutoff = 0.9, )
  kk.up@result$Description= gsub(' - Mus musculus \\(house mouse\\)','',kk.up@result$Description)
  
    p<-dotplot(kk.up)+ggtitle("CT26_sh to NC_Col_IFN_Gene_UP")
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_KEGG_UP.png", width = 7, height = 7 )
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_KEGG_UP.pdf", width = 7, height = 7 )
  write.table(kk.up,file="CT26_sh to NC_Col_IFN_KEGG_UP.txt",sep="\t",quote=F,row.names = F)
  gene_down <- unique(gene_down)
  kk.down <- enrichKEGG(gene = gene_down,
                        organism = "mmu",
                        pvalueCutoff = 0.05,
                        qvalueCutoff = 0.9,
                        keyType = "kegg")
  kk.down@result$Description= gsub(' - Mus musculus \\(house mouse\\)','',kk.down@result$Description)
  
  p<-dotplot(kk.down)+ggtitle("CT26_sh to NC_Col_IFN_KEGG_Gene_DOWN")
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_KEGG_DOWN.png", width = 7, height = 7 )
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_KEGG_DOWN.pdf", width = 7, height = 7 )
  write.table(kk.down,file="CT26_sh to NC_Col_IFN_KEGG_DOWN.txt",sep="\t",quote=F,row.names = F)
}
## GO
{
  #Up regulated genes first
  go.up <- enrichGO(gene = gene_up,
                    OrgDb = org.Mm.eg.db,
                    ont = "ALL" ,
                    pAdjustMethod = "BH",
                    pvalueCutoff = 0.05,
                    qvalueCutoff = 0.99,
                    readabl = TRUE)
  p<- barplot(go.up, showCategory =10 ,split="ONTOLOGY") + facet_grid(ONTOLOGY~., scale='free')+ggtitle("CT26_sh to NC_Col_IFN_GO_UP")
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_GO_UP.png", width = 12, height = 12 )
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_GO_UP.pdf", width = 12, height = 12 )
  write.table(go.up,file="CT26_sh to NC_Col_IFN_GO_UP.txt",sep="\t",quote=F,row.names = F)
}
{  #This step is to draw a circle plot that represent the gene associated with GO pathways(BP only)
  ego=read.table("CT26_sh to NC_Col_IFN_GO_UP.txt", header = T,sep="\t",check.names=F)      #Read GO result
  go=data.frame(Category = "BP",ID = ego$ID,Term = ego$Description, Genes = gsub("/", ", ", ego$geneID), adj_pval = ego$p.adjust)
  #Read log2FC value
  gene.up<- rownames(df[df$log2FoldChange > 0,])
  genelist <- data.frame(ID = gene.up, logFC = df[df$log2FoldChange > 0,]$log2FoldChange)
  row.names(genelist)=genelist[,1]
  
  circ <- circle_dat(go, genelist)
  termNum = 10                                     #Limiting Term numbers
  geneNum = nrow(genelist)                         #Limiting Gene Numbers
  circ$genes<- str_to_title(circ$gene)
  chord <- chord_dat(circ, genelist[1:geneNum,], go$Term[1:termNum])
  chord<- chord[1:100,]
  p<- GOChord(chord, 
              space = 0.001,           #Space between genes
              gene.order = 'logFC',    #Order by gene log2FC
              gene.space = 0.20,       #Gene name to the circ
              gene.size = 3,           #Gene name size
              border.size = 0.1,       #Gene line size
              process.label = 6)       #Font size
  p<- p+ggtitle("CT26_sh to NC_Col_IFN_GO_UP")
  ggsave(p, file="CT26_sh to NC_Col_IFN_GO_UP_Circ.pdf",width = 11,height = 12)
  ggsave(p, file="CT26_sh to NC_Col_IFN_GO_UP_Circ.png",width = 11,height = 12)  
  #Same as down regulated genes
  go.down <- enrichGO(gene = gene_down,
                      OrgDb = org.Mm.eg.db,
                      ont = "ALL",
                      pAdjustMethod = "BH",
                      pvalueCutoff = 0.99,
                      qvalueCutoff = 0.99,
                      readabl = TRUE)
  p<- barplot(go.down, showCategory =10 ,split="ONTOLOGY") + facet_grid(ONTOLOGY~., scale='free')+ggtitle("CT26_sh to NC_Col_IFN_GO_DOWN")
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_GO_DOWN.png", width = 12, height = 12 )
  ggsave(p, filename ="CT26_sh to NC_Col_IFN_GO_DOWN.pdf", width = 12, height = 12 )
  write.table(go.down,file="CT26_sh to NC_Col_IFN_GO_DOWN.txt",sep="\t",quote=F,row.names = F)
  ego=read.table("CT26_sh to NC_Col_IFN_GO_DOWN.txt", header = T,sep="\t",check.names=F)      #Read GO result
  go=data.frame(Category = "BP",ID = ego$ID,Term = ego$Description, Genes = gsub("/", ", ", ego$geneID), adj_pval = ego$p.adjust)
  #Read log2FC value
  gene.down<- rownames(df[df$log2FoldChange < 0,])
  genelist <- data.frame(ID = gene.down, logFC = df[df$log2FoldChange < 0,]$log2FoldChange)
  row.names(genelist)=genelist[,1]
  
  circ <- circle_dat(go, genelist)
  termNum = 10                                     #Limiting Term numbers
  geneNum = nrow(genelist)                         #Limiting Gene Numbers
  circ$genes <- str_to_title(circ$genes)
  chord <- chord_dat(circ, genelist[1:geneNum,], go$Term[1:termNum])
  chord<- chord[1:100,]
  p<- GOChord(chord, 
              space = 0.001,           #Space between genes
              gene.order = 'logFC',    #Order by gene log2FC
              gene.space = 0.20,       #Gene name to the circ
              gene.size = 3,           #Gene name size
              border.size = 0.1,       #Gene line size
              process.label = 6)       #Font size
  p<- p+ggtitle("CT26_sh to NC_Col_IFN_GO_DOWN")
  ggsave(p, file="CT26_sh to NC_Col_IFN_GO_DOWN_Circ.pdf",width = 11,height = 12)
  ggsave(p, file="CT26_sh to NC_Col_IFN_GO_DOWN_Circ.png",width = 11,height = 12)
}
##Gene Set Enrichment Analysis
#Here we create a function used to transfrom Gene symbol from Hsa to Mmu
{library("biomaRt")
human = useEnsembl(biomart="ensembl", dataset = "hsapiens_gene_ensembl")
mouse = useEnsembl(biomart="ensembl", dataset = "mmusculus_gene_ensembl")
convertHumanGeneList <- function(x){
  
  genesV2 = getLDS(attributes = c("hgnc_symbol"), filters = "hgnc_symbol", values = x , mart = human, attributesL = c("mgi_symbol"), martL = mouse, uniqueRows=TRUE)
  humanx <- unique(genesV2[, 2])
  
  # Print the first 6 genes found to the screen
  return(humanx)
  #This method is referred from this website:https://cloud.tencent.com/developer/article/1886310
} #Function used to transform human gene symbol to mouse gene symbol
}
#------------------------------------------------------------------------------#

#Extract gene IDs, log2FC and rank.
df_gene <- data.frame(df$log2FoldChange, df$symbol)
colnames(df_gene)<- c("Log2FC", "symbol")

{
gene_ids <- bitr(df_gene$symbol,     
                 fromType = "SYMBOL",     
                 toType =  "ENTREZID",    
                 OrgDb = org.Mm.eg.db)
gene_ids$log2FC <- df_gene$Log2FC[match(gene_ids$SYMBOL,df_gene$symbol)]
geneList <- gene_ids$log2FC
names(geneList)<- gene_ids$ENTREZID
geneList <- sort(geneList, decreasing = T, )
}
library(msigdbr)
m_df <-  msigdbr(species = "Mus musculus", category = "H")
gmt <- data.frame(m_df$gs_name, m_df$gene_symbol)
gmt <- split(x= gmt$m_df.gene_symbol, f = gmt$m_df.gs_name)
msigdbr_list <- split(x = m_df$gene_symbol, f = m_df$gs_name)

{
KEGG_gsea_result <- gseKEGG(geneList, 
                            organism = "mmu",
                            minGSSize = 10, 
                            maxGSSize = 500, 
                            pvalueCutoff=1, 
                            pAdjustMethod = "BH",
                            exponent = 1,
                            seed = TRUE,
                            verbose = TRUE,
                            by= "fgsea")
write.csv(KEGG_gsea_result, file = "CT26_sh to NC_KEGG_gsea_result.csv")
#Remove the organism tail of enriched pathways. 
KEGG_gsea_result@result$Description= gsub(' - Mus musculus \\(house mouse\\)','',KEGG_gsea_result@result$Description)
dotplot(KEGG_gsea_result)
#Rank pathways according to the value of ES
sortkk<-KEGG_gsea_result[order(KEGG_gsea_result@result$p.adjust, decreasing = F),]
head(KEGG_gsea_result@result$Description)

p<- gseaplot2(
  KEGG_gsea_result, row.names(sortkk)[1:4], 
  pvalue_table = F, title = "CT26_Sh to NC_KEGG_gsea_result", 
  base_size = 9)          #Plotting top4 ES pathways in one enrichment plot
ggsave(plot = p, filename ="CT26_sh to NC_KEGG_gsea_result_Top4.png", width = 7, height = 5 )
ggsave(plot = p, filename ="CT26_sh to NC_KEGG_gsea_result_Top4.pdf", width = 7, height = 5 , onefile = F)
p<- dotplot(KEGG_gsea_result,split=".sign", color="pvalue")+facet_grid(~.sign) #Dotplot for Result Summary
ggsave(plot = p, filename ="CT26_sh to NC_KEGG_gsea_result_Summary.png", width = 10, height = 8 )
ggsave(plot = p, filename ="CT26_sh to NC_KEGG_gsea_result_Summary.pdf", width = 10, height = 8 )
} 
###Use GSVA for multiple group comparison
library(ggplot2)
library(clusterProfiler)
library(org.Mm.eg.db)
library(dplyr)
library(msigdbr)
library(patchwork)
library(GSVA)
library(tibble)
library(enrichplot)
library(pheatmap)
library(tidyverse)
library(Seurat)
data2<- data[,-c(1,3)]
data2<- data2[!duplicated(data2$Symbol),]
data3<- subset(data2, data2$Symbol !="---", )
data3<- as.data.frame(data3)
rownames(data3)<- data3$Symbol
data3<- data3[,-1]
expr <- data3
m_df = msigdbr(species = "Mus musculus", category = "H") 
msigdbr_list = split(x = m_df$gene_symbol, f = m_df$gs_name)
expr=as.matrix(expr) 
meta<- colnames(data3)
meta<- as.matrix(meta)
rownames(meta)<- meta[,1]
group<- c("Col only", "Col+IFN", "Col only", "Col+IFN", "Col only", "Col+IFN")
meta<- cbind(meta, "treatment" = group)
meta<- as.data.frame(meta)
colnames(meta)<- c("Group", "Treatment")
kegg <- gsva(expr, msigdbr_list, kcdf="Gaussian",method = "ssgsea",parallel.sz=10) #gsva or ssGSEA are usable methods. 
write.csv(kegg, file = "CT26_HALLMARK_ssGSEA.csv")
pheatmap(kegg, show_rownames=1, show_colnames=0, annotation_col=meta, cluster_cols = F, cluster_rows = F, fontsize_row=5, filename='CT26_HALLMARK_ssGSEA_heatmap.png', width=10, height=10)
pheatmap(kegg, show_rownames=1, show_colnames=0, annotation_col=meta, cluster_cols = F, cluster_rows = F, fontsize_row=5, filename='CT26_HALLMARK_ssGSEA_heatmap.pdf', width=10, height=10)
