## This step is to create venn and GSVA heatmap for enrichment results. 

##Load packages
library(ggplot2)
library(clusterProfiler)
library(org.Mm.eg.db)
library(dplyr)
library(msigdbr)
library(patchwork)
library(GSVA)
library(tibble)
library(enrichplot)
library(pheatmap)
library(tidyverse)
library(ggpolypath)


dir.create("G:/MD/CRCLM/overlap")
setwd("G:/MD/CRCLM/overlap")

#import enrichment results, KEGG GSEA. 
CT26  <- read.csv("ct26_count_with_symbol.csv", sep = ",", header = T)
SW620 <- read.csv("HT29_SW620_count_with_symbol.csv", sep = ",", header = T)
SW620 <- SW620[,c(1:3, 7:12)]

#Transform mouse symbol to human symbol. 
#Create a function for Mmu to Hsa gene convert(ENSG ID). 
{library("biomaRt")
  human = useEnsembl(biomart="ensembl", dataset = "hsapiens_gene_ensembl")
  mouse = useEnsembl(biomart="ensembl", dataset = "mmusculus_gene_ensembl")
  convertHumanGeneList <- function(x){
    
    genesV2 = getLDS(attributes = c("mgi_symbol"), filters = "mgi_symbol", values = x , mart = mouse, attributesL = c("hgnc_symbol"), martL = human, uniqueRows=TRUE)
    humanx <- unique(genesV2[, 2])
    
    # Print the first 6 genes found to the screen
    return(humanx)
    #This method is referred from this website:https://cloud.tencent.com/developer/article/1886310
  } #Function used to transform mouse gene symbol to human gene symbol
}
mmu <- CT26$gene_ID
hsa <- convertHumanGeneList(mmu)

library(venn)
#Customize color selection
color=c( "#3C5488B2","#00A087B2", 
                    "#F39B7FB2","#91D1C2B2", 
                    "#8491B4B2", "#DC0000B2", 
                    "#7E6148B2","yellow", 
                    "darkolivegreen1", "lightskyblue", 
                    "darkgreen", "deeppink", "khaki2", 
                    "firebrick", "brown1", "darkorange1", 
                    "cyan1", "royalblue4", "darksalmon", 
                    "darkgoldenrod1", "darkseagreen", "darkorchid")
                    #读入作图文件


CT26_gsea_enrichment  <- read.csv("CT26/CT26_sh to NC_KEGG_gsea_result.csv", header = T, stringsAsFactors = T)
CT26_gsea_enrichment$Description = gsub(' - Mus musculus \\(house mouse\\)','',CT26_gsea_enrichment$Description)
CT26_GO_UP_enrichment <- read.table("CT26/CT26_sh to NC_Col_IFN_GO_UP.txt",sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)
CT26_GO_DOWN_enrichment <- read.table("CT26/CT26_sh to NC_Col_IFN_GO_DOWN.txt", sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)
CT26_KEGG_UP_enrichment <- read.table("CT26/CT26_sh to NC_Col_IFN_KEGG_UP.txt",sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)
CT26_KEGG_DOWN_enrichment <- read.table("CT26/CT26_sh to NC_Col_IFN_KEGG_DOWN.txt", sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)


SW620_gsea_enrichment <- read.csv("SW620/SW620_sh to NC_KEGG_gsea_result.csv")
SW620_gsea_enrichment$Description = gsub(' - Homo sapiens \\(human\\)','',SW620_gsea_enrichment$Description)
SW620_GO_UP_enrichment <- read.table("SW620/SW620_sh to NC_Col_IFN_GO_UP.txt", sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)
SW620_GO_DOWN_enrichment <- read.table("SW620/SW620_sh to NC_Col_IFN_GO_DOWN.txt", sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)
SW620_KEGG_UP_enrichment <- read.table("SW620/SW620_sh to NC_Col_IFN_KEGG_UP.txt", sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)
SW620_KEGG_DOWN_enrichment <- read.table("SW620/SW620_sh to NC_Col_IFN_KEGG_DOWN.txt", sep = "\t" ,header = T, stringsAsFactors = F, check.names = F)



#Select pathway list for Venn Plot. 

#1. KEGG gsea overlap
sample_list <- list(CT26_GSEA = CT26_gsea_enrichment$Description, SW620_GSEA = SW620_gsea_enrichment$Description)

gsea_overlap <- venn(sample_list, zcolor = color[1:(length(sample_list))], ggplot = T, box = F)
ggsave(gsea_overlap, filename = "CT26_SW620_GSEA_overlap.png", width = 5, height = 5)
ggsave(gsea_overlap, filename = "CT26_SW620_GSEA_overlap.pdf", width = 5, height = 5)
overlapped_pathways <- na.omit(CT26_gsea_enrichment$Description[match(CT26_gsea_enrichment$Description, SW620_gsea_enrichment$Description)])
a <- na.omit(CT26_gsea_enrichment[match(CT26_gsea_enrichment$Description, SW620_gsea_enrichment$Description),])
write.csv(a, file = "CT26_gsea_overlapped_stat.csv")
b <- na.omit(SW620_gsea_enrichment[match(SW620_gsea_enrichment$Description, CT26_gsea_enrichment$Description),]) 
write.csv(b, file = "SW620_gsea_overlapped_stat.csv")

#2. GO upregulated overlap(BP only)
CT26_GO_UP_enrichment <- subset(CT26_GO_UP_enrichment, CT26_GO_UP_enrichment$ONTOLOGY == "BP")
SW620_GO_UP_enrichment <- subset(SW620_GO_UP_enrichment, SW620_GO_UP_enrichment$ONTOLOGY == "BP")

sample_list <- list(CT26_GO_UP = CT26_GO_UP_enrichment$Description, 
                    SW620_GO_UP = SW620_GO_UP_enrichment$Description)

GO_up_overlap <- venn(sample_list, zcolor = color[3:(length(sample_list))], ggplot = T, box = F )
ggsave(GO_up_overlap, filename = "CT26_SW620_GO_UP_overlap.png", width = 5, height = 5)
ggsave(GO_up_overlap, filename = "CT26_SW620_GO_UP_overlap.pdf", width = 5, height = 5)
a <- na.omit(CT26_GO_UP_enrichment[match(CT26_GO_UP_enrichment$Description, SW620_GO_UP_enrichment$Description),])
write.csv(a, file = "CT26_GO_UP_overlapped_stat.csv")
b <- na.omit(SW620_GO_UP_enrichment[match(SW620_GO_UP_enrichment$Description, CT26_GO_UP_enrichment$Description),]) 
write.csv(b, file = "SW620_GO_UP_overlapped_stat.csv")

#3. GO downregulated overlap(BP only)
CT26_GO_DOWN_enrichment <- subset(CT26_GO_DOWN_enrichment, CT26_GO_DOWN_enrichment$ONTOLOGY == "BP")
SW620_GO_DOWN_enrichment <- subset(SW620_GO_DOWN_enrichment, SW620_GO_DOWN_enrichment$ONTOLOGY == "BP")

sample_list <- list(CT26_GO_DOWN = CT26_GO_DOWN_enrichment$Description, 
                    SW620_GO_DOWN = SW620_GO_DOWN_enrichment$Description)

GO_DOWN_overlap <- venn(sample_list, zcolor = color[4:(length(sample_list))], ggplot = T, box = F )
ggsave(GO_DOWN_overlap, filename = "CT26_SW620_GO_DOWN_overlap.png", width = 5, height = 5)
ggsave(GO_DOWN_overlap, filename = "CT26_SW620_GO_DOWN_overlap.pdf", width = 5, height = 5)
a <- na.omit(CT26_GO_DOWN_enrichment[match(CT26_GO_DOWN_enrichment$Description, SW620_GO_DOWN_enrichment$Description),])
write.csv(a, file = "CT26_GO_DOWN_overlapped_stat.csv")
b <- na.omit(SW620_GO_DOWN_enrichment[match(SW620_GO_DOWN_enrichment$Description, CT26_GO_DOWN_enrichment$Description),]) 
write.csv(b, file = "SW620_GO_DOWN_overlapped_stat.csv")

#4. KEGG upregulated overlap

sample_list <- list(CT26_KEGG_UP = CT26_KEGG_UP_enrichment$Description, 
                    SW620_KEGG_UP = SW620_KEGG_UP_enrichment$Description)

KEGG_up_overlap <- venn(sample_list, zcolor = color[3:(length(sample_list))], ggplot = T, box = F )
ggsave(KEGG_up_overlap, filename = "CT26_SW620_KEGG_UP_overlap.png", width = 5, height = 5)
ggsave(KEGG_up_overlap, filename = "CT26_SW620_KEGG_UP_overlap.pdf", width = 5, height = 5)
a <- na.omit(CT26_KEGG_UP_enrichment[match(CT26_KEGG_UP_enrichment$Description, SW620_KEGG_UP_enrichment$Description),])
write.csv(a, file = "CT26_KEGG_UP_overlapped_stat.csv")
b <- na.omit(SW620_KEGG_UP_enrichment[match(SW620_KEGG_UP_enrichment$Description, CT26_KEGG_UP_enrichment$Description),]) 
write.csv(b, file = "SW620_KEGG_UP_overlapped_stat.csv")

#5. KEGG downregulated overlap

sample_list <- list(CT26_KEGG_DOWN = CT26_KEGG_DOWN_enrichment$Description, 
                    SW620_KEGG_DOWN = SW620_KEGG_DOWN_enrichment$Description)

KEGG_DOWN_overlap <- venn(sample_list, zcolor = color[4:(length(sample_list))], ggplot = T, box = F )
ggsave(KEGG_DOWN_overlap, filename = "CT26_SW620_KEGG_DOWN_overlap.png", width = 5, height = 5)
ggsave(KEGG_DOWN_overlap, filename = "CT26_SW620_KEGG_DOWN_overlap.pdf", width = 5, height = 5)
a <- na.omit(CT26_KEGG_DOWN_enrichment[match(CT26_KEGG_DOWN_enrichment$Description, SW620_KEGG_DOWN_enrichment$Description),])
write.csv(a, file = "CT26_KEGG_DOWN_overlapped_stat.csv")
b <- na.omit(SW620_KEGG_DOWN_enrichment[match(SW620_KEGG_DOWN_enrichment$Description, CT26_KEGG_DOWN_enrichment$Description),]) 
write.csv(b, file = "SW620_KEGG_DOWN_overlapped_stat.csv")

