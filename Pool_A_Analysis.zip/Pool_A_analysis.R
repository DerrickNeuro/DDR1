#Pool A transcriptomic analysis
library(pheatmap)
library(readr)
pool_A <- read_csv("Pool_A_sg_count.csv")
pool_A_normalized <- read_csv("Pool_A_sg_normalized_count.csv")

Target <- c("Acvr1b", "Axl", "Blk", 
  "Btk", "Cdkn1a", "Csf1r", 
  "Ddr1", "Dyrk3")

match <- !is.na(match(pool_A_normalized$Gene, Target))
screen <- cbind(pool_A_normalized, "match" = match )
screen <- screen[screen$match == "TRUE",]

screen <- screen[order(screen$Gene, decreasing = F),]
pos_sg <- c("246515991",
            "246515994",
            "246517552",
            "246517551",
            "246624117",
            "246624120",
            "246524310",
            "246524312",
            "246492285",
            "246492287",
            "246510757",
            "246510758",
            "246484036",
            "246484038",
            "246536954",
            "246536955",
            "246536957")
match <- !is.na(match(screen$sgRNA, pos_sg))
screen2 <- cbind(screen, "match_sg" = match)
screen2<- screen2[order(screen2$match_sg, decreasing = T),]
screen2 <- screen2[,c(1, 2, 3, 5, 4)]
rownames(screen2)<- screen2$sgRNA
screen2bk<- t(screen2)
screen2 <- screen2[,c(-1, -2)]
screen2 <- t(screen2)
screen2<- scale(screen2)

meta <- colnames(screen2bk)
meta<- as.matrix(meta)
rownames(meta)<- meta[,1]
meta <- cbind(meta, screen2bk[2,])
meta <- as.data.frame(meta)
colnames(meta)<- c("sgRNA", "Gene")
write.table(screen2, file = "Pool_A_Heatmap.txt", sep="\t",quote=F,row.names = F)
pheatmap(screen2, show_rownames=1, show_colnames=0, 
         annotation_col=meta, cluster_cols = F, cluster_rows = T, 
         cutree_rows = 2, display_numbers = T, fontsize_number = 4,
         fontsize_row=10, fontsize = 4,filename='PoolA_Heatmap.png', width=10, height=4)
pheatmap(screen2, show_rownames=1, show_colnames=0, 
         annotation_col=meta, cluster_cols = F, cluster_rows = T, 
         cutree_rows = 2, display_numbers = T, fontsize_number = 4,
         fontsize_row=10, fontsize = 4,filename='PoolA_Heatmap.pdf', width=10, height=4)
#screen2 is the original table for heatmap drawing. 

